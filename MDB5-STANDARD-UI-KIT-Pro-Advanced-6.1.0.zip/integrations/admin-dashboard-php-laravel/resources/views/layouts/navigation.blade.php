<!-- Sidenav -->
@include('layouts.sidenav')
<!-- Sidenav -->

<!-- Navbar -->
@include('layouts.navbar')
<!-- Navbar -->